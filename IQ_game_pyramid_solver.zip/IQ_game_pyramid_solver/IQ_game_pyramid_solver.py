#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Feb  7 13:39:58 2025

@author: adrian
"""
from ShapeStorage import *
from Solution import *
from Pyramid import *

import sys
sys.setrecursionlimit(10000)

import turtle

import time

class Game:
    
    def __init__(self):
        # ss - an object of class ShapeStorage, which contains
        # all the possible shapes in the default position
        self.ss = ShapeStorage(12)
        
        # initial shapes already placed on the pyramid at the beginning of the game
        self.initialShapesId = []
        
        # playing shapes during the game
        self.playingShapesId = []

        self.solution = Solution()
        self.solution.pyramid.createPyramidLevels()

        self.possiblePositions = []


    # method of horizontally inserting shapes into the pyramid
    # used to build the pyramid with the initial shapes
    # already placed at the beginning of the game
    def insertShapeHorizontal(self, index, mirrored, rotation, level, row, col):
        # mirrored = True / False,  rotation = 90, 180, 270
        s = self.ss.shapes[index]
        if mirrored:
            s.mirror()
        if rotation:
            s.rotation = rotation
            for _ in range(int(rotation / 90)):
                s.rotate()
        self.initialShapesId.append(index) # update the initial shapes list
        occupiedBallsList = self.solution.pyramid.putHorizontal(s, level, row, col)
        if occupiedBallsList:
            self.solution.pyramid.put(index, occupiedBallsList)
        


    # method of vertically inserting shapes into the pyramid
    # used to build the pyramid with the initial shapes
    # already placed at the beginning of the game        
    def insertShapeVertical(self, index, pos, angle, level, row, col):
        # angle = 45 / 135
        s = self.ss.shapes[index]
        self.initialShapesId.append(index) # update the initial shapes list
        verticalPos = self.solution.shapeVerticalPositions(s)[pos]
        occupiedBallsList = self.solution.pyramid.putVertical(verticalPos, angle, level, row, col)
        if occupiedBallsList:
            self.solution.pyramid.put(index, occupiedBallsList)


        
    def solve(self):   
        
        # build the playing shapes list:
        for shape in self.ss.shapes:
            if shape.id not in self.initialShapesId:
                self.playingShapesId.append(shape.id)
        # print(self.playingShapesId)
        
        # build all possible positions for the playing shapes:
        for shapeId in self.playingShapesId:
            self.possiblePositions.append(self.solution.pyramidOccupiedBallsBasedOnTheShapePositions(self.ss.shapes[shapeId]))

       
        try:
            self.back(0)
            return True
        except:
            return False


    def printLevel(self, level):
        for row in range(len(level)):
            for col in range(len(level)):
                if level[row][col] == None:
                    print("X" + "\t", end = "")
                else:
                    print(str(level[row][col]) + "\t", end = "")
            print()
        
    def checkSolution(self):
        if self.solution.pyramid.top == None:
            return False
        for level in self.solution.pyramid.levels:
            for row in range(len(level)):
                for col in range(len(level)):
                    if level[row][col] == None:
                        return False
        return True


    def checkValidPos(self, pos):
        return self.solution.pyramid.checkAdjacentCellsForOverlap(pos)

    
    def back(self, k):
        if k == len(self.playingShapesId) and self.checkSolution():
            raise Exception("The solution was found.")
        else:
            for pos in self.possiblePositions[k]:
                if self.checkValidPos(pos):
                    self.solution.pyramid.put(self.playingShapesId[k], pos)
                    self.back(k + 1)
                    self.solution.pyramid.pop(pos)
                    
    def printSolution(self):
        print()
        print("************************")
        for level in self.solution.pyramid.levels:
            self.printLevel(level)
            print()
        if self.solution.pyramid.top == None:
            print("X")
        else:
            print(str(self.solution.pyramid.top))
        print("************************")
        print()
                    
    def drawSolution(self):
        
        def inner_drawBall(r, x, y, color):
            turtle.hideturtle()
            turtle.penup()
            turtle.setpos(x, y)
            turtle.pendown()
            turtle.dot(r + 5)
            turtle.dot(r, color)
            turtle.update()
        
        def inner_aaa():
            elevation = 0
            val = 6 * r
            indentation = 0
            for level in self.solution.pyramid.levels:
                size = len(level)
                for row in range(size):
                    for col in range(size):
                        reverseRow = size - row - 1
                        if level[reverseRow, col] or level[reverseRow, col] == 0:
                            color = self.ss.shapes[level[reverseRow, col]].color
                        else:
                            color = "white"
                        inner_drawBall(r, leftmostColumnX + col * step + indentation, bottomRowY + row * step + elevation, color)
                elevation += val
                val -= r
                indentation += r / 2
            if self.solution.pyramid.top or self.solution.pyramid.top == 0:
                color = self.ss.shapes[self.solution.pyramid.top].color
            else:
                color = "white"
            inner_drawBall(r, -5, bottomRowY + elevation, color)   
            
        r = 100
        step = r + 5
        screen = turtle.Screen()
        WIDTH = 2 * r + 4 * step
        HEIGHT = 2000
        screen.setup(WIDTH, HEIGHT)

        leftmostColumnX = -WIDTH / 2 + 100
        bottomRowY = -HEIGHT / 2 + 100

        turtle.tracer(0, 0)
        turtle.speed_value = 0

        inner_aaa()

        turtle.done()
        turtle.mainloop()


# game = Game()

# *****************************************************************************
# game #82: INCOMPLET INPUT
# game.insertShapeHorizontal(4, False, 180, 0, 0, 4)
# game.insertShapeHorizontal(6, False, 180, 0, 3, 3)
# game.insertShapeHorizontal(7, False, 90, 0, 0, 0)
# game.insertShapeHorizontal(9, True, 90, 0, 3, 0)
# game.insertShapeHorizontal(10, True, 270, 0, 1, 4)
# game.insertShapeHorizontal(2, False, 90, 1, 0, 0)
# game.insertShapeHorizontal(1, False, 180, 1, 1, 3)

# *****************************************************************************
# game #86: INCOMPLET INPUT
# game.insertShapeHorizontal(0, False, 0, 0, 4, 0)
# game.insertShapeHorizontal(2, False, 90, 0, 0, 0)

# *****************************************************************************
# game #111:
# game.insertShapeHorizontal(11, True, 270, 0, 1, 1)
# game.insertShapeHorizontal(2, False, 90, 0, 0, 0)
# game.insertShapeHorizontal(10, True, 270, 0, 1, 4)
# game.insertShapeVertical(7, -1, 45, 0, 3, 3)

# *****************************************************************************
# game #117:
# game.insertShapeHorizontal(2, False, 90, 0, 0, 0)
# game.insertShapeHorizontal(9, True, 0, 0, 4, 4)

# *****************************************************************************
# game #120:
# game.insertShapeHorizontal(10, True, 0, 0, 2, 4)

# game.solve()
# game.drawSolution()