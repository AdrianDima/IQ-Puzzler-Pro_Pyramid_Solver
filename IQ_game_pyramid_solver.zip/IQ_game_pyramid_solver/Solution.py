#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Feb  7 13:39:58 2025

@author: adrian
"""
#file  -- Solution.py --

from Pyramid import *
import copy
from random import shuffle
    
class Solution:
    
    def __init__(self):
        self.pyramid = Pyramid()


    # method to build all possible horizontal and vertical positions of a shape
    # a position is stored as a list of occupied balls in pyramid
    # an occupied ball in pyramid is stored as [level, row, column]
    def pyramidOccupiedBallsBasedOnTheShapePositions(self, shape):
        pyramidOccupiedBalls = self.pyramidOccupiedBallsBasedOnTheShapeHorizontalPositions(shape)
        for verticalPos in self.pyramidOccupiedBallsBasedOnTheShapeVerticalPositions(shape):
            pyramidOccupiedBalls.append(verticalPos)
        shuffle(pyramidOccupiedBalls)
        return pyramidOccupiedBalls

    # method to build all possible vertical positions of a shape
    # a position is stored as a list of occupied balls in pyramid
    # an occupied ball in pyramid is stored as [level, row, column]
    def pyramidOccupiedBallsBasedOnTheShapeVerticalPositions(self, shape):
        pyramidOccupiedBalls = []
        for verticalPos in self.shapeVerticalPositions(shape): # for this vertical position
            for level in range(self.pyramid.baseSize - 1):
                levelSize = len(self.pyramid.levels[level])
                for row in range(levelSize):
                    for col in range(levelSize):
                        balls = self.pyramid.putVertical(verticalPos, 45, level, row, col)
                        if balls:
                            pyramidOccupiedBalls.append(balls)
                        balls = self.pyramid.putVertical(verticalPos, 135, level, row, col)
                        if balls:
                            pyramidOccupiedBalls.append(balls)
        return pyramidOccupiedBalls


    # method to build all possible horizontal positions of a shape
    # a position is stored as a list of occupied balls in pyramid
    # an occupied ball in pyramid is stored as [level, row, column]
    def pyramidOccupiedBallsBasedOnTheShapeHorizontalPositions(self, shape):
        pyramidOccupiedBalls = []
        for horizontalPos in self.shapeHorizontalPositions(shape): # for this horizontal position
            for level in range(self.pyramid.baseSize - 1):
                levelSize = len(self.pyramid.levels[level])
                for row in range(levelSize):
                    for col in range(levelSize):
                        balls = self.pyramid.putHorizontal(horizontalPos, level, row, col)
                        if balls:
                            pyramidOccupiedBalls.append(balls)
        return pyramidOccupiedBalls

        
    # method to build all possible horizontal positions of a shape on a level:
    def shapeHorizontalPositions(self, shape):
        possibleHorizontalPositions = []
        possibleHorizontalPositions.append(shape)
        # this shape has only 4 possible positions, although it is not symmetrical:
        #  OO
        # OO 
        if shape.id == 9:
            shapeCopy = copy.deepcopy(possibleHorizontalPositions[-1])
            shapeCopy.rotate() # 90
            possibleHorizontalPositions.append(shapeCopy)
            
            shapeCopy = copy.deepcopy(possibleHorizontalPositions[0])
            shapeCopy.mirror()
            possibleHorizontalPositions.append(shapeCopy)
            
            shapeCopy = copy.deepcopy(possibleHorizontalPositions[-1])
            shapeCopy.rotate() # 90
            possibleHorizontalPositions.append(shapeCopy)
        else:
            for _ in range(3):
                shapeCopy = copy.deepcopy(possibleHorizontalPositions[-1])
                shapeCopy.rotate() # 90, 180, 270
                possibleHorizontalPositions.append(shapeCopy)
    
            if not shape.symmetrical:
                shapeCopy = copy.deepcopy(possibleHorizontalPositions[-1])
                shapeCopy.mirror()
                possibleHorizontalPositions.append(shapeCopy)
                for _ in range(3):
                    shapeCopy = copy.deepcopy(possibleHorizontalPositions[-1])
                    shapeCopy.rotate() # 90, 180, 270
                    possibleHorizontalPositions.append(shapeCopy)
                
        return possibleHorizontalPositions

    
    # method to build all possible vertical positions of a shape
    def shapeVerticalPositions(self, shape):
        
        # nested function:
        def addLevels(levels):
            if levels:
                already = False
                for alreadyLevels in possibleVerticalPositions:
                    if levels == alreadyLevels:
                        already = True
                        break
                if not already:
                    possibleVerticalPositions.append(levels)
        
        # nested function:       
        def calculateLevels(shape, angle):
            shapeCopy = copy.deepcopy(shape)
            for _ in range(int(angle / 90)):
                shapeCopy.rotate()
            shapeCopy.firstQuadrantTranslate()
            shapeCopy.translateX()
            levels = shapeCopy.createBaseVerticalPosition()
            mirroredLevels = shapeCopy.createMirroredVerticalPosition(levels)
            return levels, mirroredLevels
        
        # nested function:
        # the levels are translated so that
        # the ball on the leftmost abscissa has x = 0:
        def levelsTranslateX(levels):
            if levels and len(levels[0]) > 1:
                minAbscisaX = 0
                for point in levels[0]:
                    if minAbscisaX > point[0]:
                        minAbscisaX = point[0]
                for level in levels:
                    for point in level:
                        point[0] += abs(minAbscisaX)
                        point[1] += abs(minAbscisaX)
                for level in levels:
                    level.sort()
        
        # begin:
        possibleVerticalPositions = []
        levels = shape.createBaseVerticalPosition()
        levelsTranslateX(levels)
        possibleVerticalPositions.append(levels)
        
        if shape.id not in [3, 7]:
            mirroredLevels = shape.createMirroredVerticalPosition(levels)
            levelsTranslateX(mirroredLevels)
            possibleVerticalPositions.append(mirroredLevels)

        for angle in [90, 180, 270]:
            levels, mirroredLevels = calculateLevels(shape, angle)
            levelsTranslateX(levels)
            addLevels(levels)
            levelsTranslateX(mirroredLevels)
            addLevels(mirroredLevels)
        
        mirroreShape = copy.deepcopy(shape)
        mirroreShape.mirror()
        mirroreShape.firstQuadrantTranslate()
        mirroreShape.translateX()
        
        for angle in [90, 180, 270]:
            levels, mirroredLevels = calculateLevels(mirroreShape, angle)
            levelsTranslateX(levels)
            addLevels(levels)
            levelsTranslateX(mirroredLevels)
            addLevels(mirroredLevels)

        return possibleVerticalPositions