
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Mar 10 22:39:35 2025

@author: adrian
"""

# Import module
import tkinter as tk

# Create object
root = tk.Tk()
root.title("IQ game pyramid solver")

w = 870
h = 1450
# set minimum window size value
root.minsize(w, h)
# set maximum window size value
root.maxsize(w, h)

# center a window on the screen:
def center_window(window):
    window.update_idletasks()
    width = window.winfo_width()
    height = window.winfo_height()
    screen_width = window.winfo_screenwidth()
    screen_height = window.winfo_screenheight()
    x = (screen_width - width) // 2
    y = (screen_height - height) // 2
    window.geometry(f"{width}x{height}+{x}+{y}")

center_window(root)

from IQ_game_pyramid_solver import *
game = Game()
# n - number of shapes
n = len(game.ss.shapes)
# all shapes colors:
colors = []
for index in range(n):
    color = game.ss.shapes[index].color
    colors.append(color)

import os
cwd = os.getcwd()
photos = []
for color in colors:
    color_file = "shape_" + color + ".png"
    photo = os.sep.join([cwd, "pictures", color_file])
    photos.append(tk.PhotoImage(file = photo))


frame_left = tk.Frame(root, bg='dark sea green', bd=3, cursor='hand2',
                              highlightcolor='red', highlightthickness=2, highlightbackground='black', 
                              relief=tk.RAISED)
frame_left.grid(row = 0, column = 0, padx=10, pady = 10)

frame_right = tk.Frame(root, bg='dark sea green', bd=3, cursor='hand2',
                              highlightcolor='red', highlightthickness=2, highlightbackground='black', 
                              relief=tk.RAISED)
frame_right.grid(row = 0, column = 1, padx=10, pady=10)

# create shape buttons:
index = 0
button_row = 0
current_side = tk.LEFT
for photo in photos:
    # By defining a temporary variable temp, the value of that
    # var gets fixed at the moment when the button is defined:
    button = tk.Button(frame_left, image = photo, command = lambda temp = index : shapeButton(temp))
    button.grid(row = button_row, column = index % 2, padx=10, pady=10)
    index += 1
    if index % 2 == 0:
        button_row += 1

    
shape_index = 0
clear = False

def shapeButton(index):
    global shape_index
    shape_index = index
    global clear
    clear = False

# create ball buttons:
tempTop = None
tempLevels = []

level_size = game.solution.pyramid.baseSize
while level_size > 1:
    tempLevels.append(np.full((level_size, level_size), None))
    level_size -= 1

def ballButtonChange(n):
    # function to get the index and the identity (button name)
    button = button_identities[n]
    btn_solve["state"] = "normal" 
    
    def corresponding_position_in_pyramid(n, val):
        if n == 0:
            global tempTop
            tempTop = val
        else:
            for level in tempLevels:
                for row in range(len(level)):
                    for col in range(len(level)):
                        n -= 1
                        if n == 0:
                            level[row][col] = val
                            return    
    
    if clear:
        dot = os.sep.join([cwd, "pictures", "dot_.png"])
        corresponding_position_in_pyramid(n, None)

        def check_pyramid_empty():
            if tempTop != None:
                return False
            else:
                for level in tempLevels:
                    for r in range(len(level)):
                        for c in range(len(level)):
                            if level[r][c] != None:
                                return False
            return True
                        
        if check_pyramid_empty():
            btn_solve["state"] = "disabled" 

    else:
        color = "dot_" + colors[shape_index] + ".png"
        dot = os.sep.join([cwd, "pictures", color])
        corresponding_position_in_pyramid(n, shape_index)
    
    photo = tk.PhotoImage(file = dot)
    button.configure(image = photo)
    button.photo = photo


from functools import partial
button_identities = []
dot = os.sep.join([cwd, "pictures", "dot_.png"])
photo = tk.PhotoImage(file = dot)

# create top button:
button = tk.Button(frame_right, image = photo, command = partial(ballButtonChange, 0))
button.pack(pady=10)

# add the button's identity to a list:
button_identities.append(button)


# create layers buttons:
button_index = 1
for level in tempLevels:
    frame = tk.Frame(frame_right, cursor='hand2', relief=tk.RAISED)
    frame.pack(side=tk.BOTTOM, padx=10, pady=10)

    for row in range(len(level)):
        for col in range(len(level)):
            button = tk.Button(frame, image = photo, command = partial(ballButtonChange, button_index))
            button.grid(row = row, column = col)
            # add the button's identity to a list:
            button_identities.append(button)
            button_index += 1


frame_bottom_buttons = tk.Frame(root, bg='lightblue', bd=3, cursor='hand2',
                              highlightcolor='red', highlightthickness=2, highlightbackground='black', 
                              relief=tk.RAISED)
frame_bottom_buttons.grid(row = 1, column = 0, padx=10, pady=10, columnspan = 2)

# Creating the button "info" with specified options:
btn_info = tk.Button(frame_bottom_buttons, text = 'info', command = lambda: infoCommand())
# Set the position of button
btn_info.pack(side=tk.LEFT, padx=10, pady=10)

def infoCommand():
    
    window = tk.Toplevel()
    window.wm_title("")
    
    w = 550
    h = 735

    window.minsize(w, h)
    window.maxsize(w, h)
    
    center_window(window)
    
    frame = tk.Frame(window)
    frame.pack(pady = 10)
    
    s = "How to use this solver:\n\
Click the button corresponding to the piece you want to place on the pyramid. \
Click by click defines the chosen piece on the pyramid. \
If you put a ball wrong, you can use the \"ball clear\" button."
       
    title = tk.Label(frame, bg='dark sea green', bd=3, text = s, anchor="w", wraplength=530, justify="left")
    title.config(font =("TkDefaultFont", 10))
    title.pack(side=tk.TOP)
    
    
    image = "IQ_physical_game_pyramid.png"
    path = os.sep.join([cwd, "pictures", image])
    photo = tk.PhotoImage(file = path)
    image1 = tk.Label(frame, image = photo)
    image1.photo = photo
    image1.pack(side=tk.TOP)
    
    s = "Please note that this version of the solver does not check \
the correctness of the input data, i.e. whether the pieces are \
correctly defined."
    
    text1 = tk.Label(frame, bg='dark sea green', bd=3, text = s, anchor="w", wraplength=530, justify="left")
    text1.config(font =("TkDefaultFont", 10))
    text1.pack(side=tk.TOP)  

    btn_ok = tk.Button(window, text = "OK", command = window.destroy)
    btn_ok.pack(padx = 10, pady = 10)

# Creating the button "clear" with specified options
btn_clear = tk.Button(frame_bottom_buttons, text = 'ball clear', command = lambda: clearCommand())
# Set the position of button
btn_clear.pack(side=tk.LEFT, padx=10, pady=10)

def clearCommand():
    global clear
    clear = True

# Creating the button "wipe" with specified options
btn_wipe = tk.Button(frame_bottom_buttons, text = 'wipe the table', 
                     command = lambda: wipeCommand())
# Set the position of button
btn_wipe.pack(side=tk.LEFT, padx=10, pady=10)

def wipeCommand():
    dot = os.sep.join([cwd, "pictures", "dot_.png"])
    photo = tk.PhotoImage(file = dot)
    for button in button_identities:
        button.configure(image = photo)
        button.photo = photo
    
    global tempTop
    tempTop = None
    for level in tempLevels:
        for r in range(len(level)):
            for c in range(len(level)):
                level[r][c] = None   

    btn_solve["state"] = "disabled"

# Creating the button "solve" with specified options
btn_solve = tk.Button(frame_bottom_buttons, text = 'Solve', 
                      command = lambda: solveCommand(), state = "disabled")
# Set the position of button
btn_solve.pack(side=tk.LEFT, padx=10, pady=10)

import time
def solveCommand():
    if tempTop != None:
        game.initialShapesId.append(tempTop)
        game.solution.pyramid.top = tempTop
    level_index = 0
    
    for level in tempLevels:
        for row in range(len(level)):
            for col in range(len(level)):
                if level[row][col] != None:
                    game.solution.pyramid.levels[level_index][row][col] = level[row][col]
                    if level[row][col] not in game.initialShapesId:
                        game.initialShapesId.append(level[row][col])
        level_index += 1

    root.destroy()

    start_time = time.time()
    game.solve()
    print("Running time: %s seconds" % round((time.time() - start_time), 1))
    
    game.drawSolution()

# Execute tkinter
root.mainloop()

