#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Feb  7 13:39:58 2025

@author: adrian
"""
#file  -- Pyramid.py -

import numpy as np

class Pyramid:
    
    def __init__(self):
        self.baseSize = 5
        self.levels = []
        self.top = None
  
    def createPyramidLevels(self):
        level_size = self.baseSize
        # for _ in range(self.baseSize - 1):
        while level_size > 1:
            self.levels.append(np.full((level_size, level_size), None))
            level_size -= 1

    # method to build a vertical position of a shape
    # the position is stored as a list of occupied balls in pyramid
    # an occupied ball in pyramid is stored as [level, row, column]
    def putVertical(self, verticalPos, angle, level, row, col):
        balls = []
        levelSize = self.baseSize - level
        if row > levelSize - 1 or col > levelSize - 1:
            return
        h = 0
        for verticalPosLevel in verticalPos:
            if verticalPosLevel:
                h += 1
        if level + h > self.baseSize:
            return
        elevation = 0 # starting from level
        for verticalPosLevel in verticalPos:       
            for pos in verticalPosLevel:
                rowCurr = levelSize - 1 - row
                rowCurr -= int((pos[0] - elevation) / 2)
                if angle == 45:
                    colCurr = col                
                    colCurr += int((pos[1] - elevation) / 2)
                else:
                    colCurr = col - elevation
                    colCurr -= int((pos[1] - elevation) / 2)
                    
                if levelSize > 1:
                    if rowCurr > len(self.levels[level]) - 1 or rowCurr < 0 or \
                        colCurr > len(self.levels[level]) - 1 or colCurr < 0:
                        return
                    balls.append([level, rowCurr, colCurr])
                else:
                    if len(verticalPosLevel) > 1:
                        return
                    if rowCurr != 0 or colCurr != 0:
                        return
                    balls.append([level]) # pyramid top
            levelSize -= 1
            level += 1
            elevation += 1
        if self.checkAdjacentCellsForOverlap(balls):
            return balls
        return


    # method to build a horizontal position of a shape
    # the position is stored as a list of occupied balls in pyramid
    # an occupied ball in pyramid is stored as [level, row, column]
    def putHorizontal(self, horizontalPos, level, row, col):
        balls = []
        for ball in horizontalPos.balls:
            rowCurr = int(row - ball[1] / 100)
            colCurr = int(col + ball[0] / 100)
            # check boundaries:
            if rowCurr > len(self.levels[level]) - 1 or rowCurr < 0 or \
                colCurr > len(self.levels[level]) - 1 or colCurr < 0:
                    return
            balls.append([level, rowCurr, colCurr])
        if self.checkAdjacentCellsForOverlap(balls):
            return balls
        return

            
    def put(self, index, occupiedBallsList):
        for ball in occupiedBallsList:
            if len(ball) == 1:
                self.top = index
            else:
                self.levels[ball[0]][ball[1]][ball[2]] = index
            

    def pop(self, occupiedBallsList):
        for ball in occupiedBallsList:
            if len(ball) == 1:
                self.top = None
            else:
                self.levels[ball[0]][ball[1]][ball[2]] = None


    # check adjacent cells for overlap:
    def checkAdjacentCellsForOverlap(self, occupiedBallsList):
        for ball in occupiedBallsList:
            if len(ball) == 1:
                if self.top or self.top == 0:
                    return False
            else:
                if self.levels[ball[0]][ball[1]][ball[2]] or self.levels[ball[0]][ball[1]][ball[2]] == 0:
                    return False
        return True