#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Feb  7 13:39:58 2025

@author: adrian
"""

#file  -- Shape.py --

import itertools
import copy

class Shape:
    
    id_iter = itertools.count()
    
    def __init__(self):
        self.balls = [[0, 0]]
        self.symmetrical = True
        self.minX = 0
        self.minY = 0
        self.maxX = 0
        self.maxY = 0
        self.id = next(self.id_iter)

    def addBall(self, x, y):
        self.balls.append([x, y])
        
    def mirror(self):
        if self.symmetrical == False:
            for ball in self.balls:
                ball[0] = -ball[0]  
    
    def rotate(self):
        for ball in self.balls:
            temp = ball[0]
            ball[0] = ball[1]
            ball[1] = -temp
            
    def extremeCoordinates(self):
        self.minX = 0
        self.minY = 0
        self.maxX = 0
        self.maxY = 0
        for ball in self.balls:
            if ball[0] < self.minX:
                self.minX = ball[0]
            if ball[0] > self.maxX:
                self.maxX = ball[0]
            if ball[1] < self.minY:
                self.minY = ball[1]
            if ball[1] > self.maxY:
                self.maxY = ball[1]

    # a vertical position is built, as if the shape were rotated counterclockwise by 45 degrees
    def createBaseVerticalPosition(self):
        self.restoreTheOriginInTheFirstBall()
        self.extremeCoordinates()
        # check if the "rotation" is possible, that is to check
        # if there are balls located in quadrant IV, under the second bisector:
        if self.minX < 0:
            for ball in self.balls:
                if ball[0] < 0 and abs(ball[0]) > ball[1]:
                    return None

        levels = [ [] for _ in range(5) ]
        # counterclockwise rotation with 45 around the origin:
        for ball in self.balls:
            level = int(abs((ball[0] + ball[1]) / 100))
            xy = int((ball[0] - ball[1]) / 100)
            levels[level].append([xy, xy])

        return levels


    def firstQuadrantTranslate(self):
        self.extremeCoordinates()
        if self.minX < 0:
            for ball in self.balls:
                ball[0] += abs(self.minX)
        if self.minY < 0:
            for ball in self.balls:
                ball[1] += abs(self.minY)

                
    # method to position the shape so that
    # the lowest and leftmost node becomes the rotation point:
    def translateX(self):
        self.extremeCoordinates()
        minX = self.maxX
        for ball in self.balls:
            if ball[1] == 0:
                if ball[0] < minX:
                    minX = ball[0]
        if minX != 0:
            for ball in self.balls:
                ball[0] -= minX

        
    # before create vertical position,
    # the first ball must have coordinates 0,0:
    def restoreTheOriginInTheFirstBall(self):
        i = 0
        while self.balls[i][0] != 0 or self.balls[i][1] != 0:
            i += 1
        self.balls[i][0] = self.balls[0][0]
        self.balls[i][1] = self.balls[0][1]
        self.balls[0][0] = 0
        self.balls[0][1] = 0  

                
    def createMirroredVerticalPosition(self, levels):
        if levels:
            mirrored = copy.deepcopy(levels)
            for level in mirrored:
                for pos in level:
                    pos[0] *= -1
                    pos[1] *= -1
            return mirrored
        return None
    
    
    def color(self, color):
        self.color = color

        
    def __eq__(self, other):
        if self.color != other.color:
            return False
        for ball_self in self.balls:
            found = False
            for ball_other in other.balls:
                if ball_self[0] == ball_other[0] and \
                    ball_self[1] == ball_other[1]:
                        found = True
                        break
            if not found:
                return False
        return True

    def numberOfBalls(self):
        return len(self.balls)


    def draw(self, x, y):
        for ball in self.balls:
            t.penup()
            t.setpos(x + ball[0] + XORIG, y + ball[1] + YORIG)
            t.pendown()
            t.dot(100, self.color)